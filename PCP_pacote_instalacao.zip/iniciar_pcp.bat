@echo off
setlocal
cd /d "%~dp0"
title Sistema PCP - NAO FECHE ESTA JANELA
set PYTHONUTF8=1
set PCP_PORT=5000
if not exist venv\Scripts\python.exe goto sem_instalacao
echo Iniciando o sistema PCP. NAO feche esta janela enquanto estiver produzindo.
echo Para usar, abra o navegador em http://localhost:%PCP_PORT%
echo As etiquetas abrem em PDF numa nova aba do navegador: imprima com Ctrl+P.
echo.
start "" /min cmd /c "ping -n 6 127.0.0.1 >nul & start http://localhost:%PCP_PORT%"
venv\Scripts\python.exe apontamento_producao_pcp.py
echo.
echo O sistema parou. Leia a mensagem acima.
pause
exit /b 1
:sem_instalacao
echo O sistema ainda nao foi instalado. Execute primeiro o instalar_pcp.bat
pause
exit /b 1
