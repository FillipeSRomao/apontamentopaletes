@echo off
setlocal
cd /d "%~dp0"
title Instalacao do sistema PCP
echo ==== Instalacao do sistema PCP ====
echo.
python --version >nul 2>nul
if errorlevel 1 goto sem_python
python --version
echo.
if not exist venv\Scripts\python.exe python -m venv venv
if errorlevel 1 goto erro
if exist wheels goto offline
echo Instalando as bibliotecas pela internet. Aguarde...
venv\Scripts\python.exe -m pip install --upgrade pip
venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto erro
goto conferir
:offline
echo Pasta wheels encontrada: instalando sem internet. Aguarde...
venv\Scripts\python.exe -m pip install --no-index --find-links wheels -r requirements.txt
if errorlevel 1 goto erro
:conferir
venv\Scripts\python.exe -c "import flask, reportlab, openpyxl, PIL; print('Bibliotecas OK')"
if errorlevel 1 goto erro
echo.
if not exist ROMANEIO_DE_PALETE.xlsx echo [ATENCAO] Falta o arquivo ROMANEIO_DE_PALETE.xlsx nesta pasta.
if not exist logo_oasis.png echo [ATENCAO] Falta o arquivo logo_oasis.png nesta pasta.
echo.
echo Instalacao concluida. Agora use o arquivo iniciar_pcp.bat
pause
exit /b 0
:sem_python
echo [ERRO] O Python nao foi encontrado.
echo Instale o Python 3.13 marcando a opcao Add python.exe to PATH,
echo feche esta janela e abra o instalar_pcp.bat de novo.
pause
exit /b 1
:erro
echo.
echo [ERRO] A instalacao falhou. Tire uma foto desta tela e envie para o suporte.
pause
exit /b 1
